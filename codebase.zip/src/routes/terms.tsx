import { createFileRoute, Link } from "@tanstack/react-router";
import { SiteFooter } from "@/components/SiteFooter";

export const Route = createFileRoute("/terms")({
  component: TermsPage,
  head: () => ({
    meta: [
      { title: "Användarvillkor — PrylKollen" },
      { name: "description", content: "Användarvillkor för PrylKollen, drivet av Lindgren." },
    ],
  }),
});

function TermsPage() {
  return (
    <div className="min-h-screen bg-background flex flex-col">
      <main className="mx-auto w-full max-w-3xl flex-1 px-4 py-12 sm:py-16">
        <Link to="/" className="text-xs font-semibold uppercase tracking-widest text-muted-foreground hover:text-foreground">
          ← PrylKollen
        </Link>
        <h1 className="mt-4 text-3xl font-bold tracking-tight">Användarvillkor</h1>
        <p className="mt-2 text-sm text-muted-foreground">Senast uppdaterad: {new Date().toLocaleDateString("sv-SE")}</p>

        <div className="prose prose-sm mt-8 max-w-none text-foreground/90 [&_h2]:mt-8 [&_h2]:text-lg [&_h2]:font-semibold [&_p]:mt-3 [&_p]:leading-relaxed [&_ul]:mt-3 [&_ul]:list-disc [&_ul]:pl-5 [&_li]:mt-1">
          <h2>1. Säljare och avtal</h2>
          <p>
            Tjänsten PrylKollen ("Tjänsten") tillhandahålls av Lindgren ("vi", "oss"). Genom att skapa ett konto eller använda
            Tjänsten godkänner du dessa villkor och ingår ett bindande avtal med Lindgren.
          </p>

          <h2>2. Behörighet</h2>
          <p>Du måste vara minst 18 år eller ha målsmans samtycke för att använda Tjänsten.</p>

          <h2>3. Tjänsten</h2>
          <p>
            PrylKollen låter dig fotografera och katalogisera dina ägodelar med hjälp av AI för identifiering och beskrivning.
            Tjänsten erbjuds i en gratisversion (5 fotoanalyser) samt en betald Pro-plan med obegränsade analyser.
          </p>

          <h2>4. Kontoregistrering</h2>
          <p>
            Du ansvarar för att uppgifter du anger är korrekta och för att hålla dina inloggningsuppgifter konfidentiella.
            Du är ansvarig för all aktivitet som sker via ditt konto.
          </p>

          <h2>5. Tillåten användning</h2>
          <p>Du får inte:</p>
          <ul>
            <li>använda Tjänsten i strid med lag eller för bedrägeri, spam eller skadlig kod;</li>
            <li>göra intrång i immateriella rättigheter;</li>
            <li>försöka kringgå säkerhetsåtgärder, skanna, skrapa eller belasta Tjänsten på onormalt sätt;</li>
            <li>ladda upp innehåll du inte har rätt till eller som är olagligt, hatiskt eller skadligt;</li>
            <li>använda AI-funktioner för att skapa vilseledande, kränkande eller olagligt innehåll.</li>
          </ul>

          <h2>6. AI-genererat innehåll</h2>
          <p>
            Tjänsten använder AI för att identifiera föremål och föreslå värden. AI-utdata kan innehålla fel och ska inte
            betraktas som professionell rådgivning (t.ex. vid försäkringsärenden eller värdering). Du ansvarar för att
            verifiera resultat innan du förlitar dig på dem. Vi förbehåller oss rätten att moderera, filtrera eller stänga av
            konton som missbrukar AI-funktionerna.
          </p>

          <h2>7. Immateriella rättigheter</h2>
          <p>
            Lindgren äger Tjänsten och tillhörande mjukvara, varumärken och dokumentation. Du behåller rättigheterna till de
            bilder och uppgifter du laddar upp, men ger oss en begränsad licens att behandla dem för att leverera Tjänsten.
          </p>

          <h2>8. Betalning, abonnemang och återbetalning</h2>
          <p>
            Vår orderhantering sker via vår onlineåterförsäljare Paddle.com. Paddle.com är Merchant of Record för alla
            beställningar. Paddle hanterar alla kundtjänstärenden gällande betalningar och återbetalningar. För fullständiga
            villkor kring betalning, fakturering, skatt, uppsägning och återbetalning hänvisar vi till{" "}
            <a className="underline" href="https://www.paddle.com/legal/checkout-buyer-terms" target="_blank" rel="noopener noreferrer">
              Paddles köpvillkor
            </a>{" "}
            samt vår <Link to="/refund-policy" className="underline">återbetalningspolicy</Link>.
          </p>
          <p>
            Pro-prenumerationen kostar 50 kr/månad och förnyas automatiskt tills den sägs upp. Du kan när som helst säga
            upp prenumerationen från ditt konto eller via Paddles kundportal.
          </p>

          <h2>9. Tillgänglighet</h2>
          <p>
            Vi strävar efter att Tjänsten ska vara tillgänglig dygnet runt men kan inte garantera oavbruten eller felfri
            drift. Underhåll, uppdateringar och tekniska fel kan medföra avbrott.
          </p>

          <h2>10. Avstängning och uppsägning</h2>
          <p>
            Vi kan stänga av eller avsluta din åtkomst vid: väsentligt brott mot dessa villkor, utebliven betalning,
            säkerhets- eller bedrägeririsk eller upprepade policyöverträdelser. Vid uppsägning kan du exportera dina data
            inom rimlig tid varefter de raderas.
          </p>

          <h2>11. Ansvarsbegränsning</h2>
          <p>
            Tjänsten tillhandahålls "i befintligt skick". I den utsträckning lagen tillåter friskriver vi oss från
            underförstådda garantier. Vårt sammanlagda ansvar är begränsat till de avgifter du betalat under de senaste
            tolv månaderna. Vi ansvarar inte för indirekta skador som utebliven vinst eller förlust av data. Inget i dessa
            villkor begränsar ansvar som inte kan friskrivas enligt lag.
          </p>

          <h2>12. Ändringar</h2>
          <p>
            Vi kan uppdatera dessa villkor. Väsentliga ändringar meddelas via Tjänsten eller e-post. Fortsatt användning
            efter ändringar innebär att du accepterar de uppdaterade villkoren.
          </p>

          <h2>13. Tillämplig lag</h2>
          <p>Svensk lag tillämpas. Tvister avgörs av allmän domstol med Stockholms tingsrätt som första instans.</p>

          <h2>14. Kontakt</h2>
          <p>Frågor om villkoren? Kontakta Lindgren via supporten i appen.</p>
        </div>
      </main>
      <SiteFooter />
    </div>
  );
}

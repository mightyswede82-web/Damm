import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useCallback, useEffect, useRef, useState } from "react";
import { analyzeFrame, deepDiveItem } from "@/lib/inventory.functions";
import { getUsageStatus } from "@/lib/payments.functions";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Camera, CameraOff, Loader2, Package, Trash2, Download, ImageOff, ImagePlus, Sparkles, LogOut } from "lucide-react";
import { toast, Toaster } from "sonner";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useAuth } from "@/hooks/use-auth";
import { supabase } from "@/integrations/supabase/client";
import { PaywallDialog } from "@/components/PaywallDialog";
import { PaymentTestModeBanner } from "@/components/PaymentTestModeBanner";
import { PublicLanding } from "@/components/PublicLanding";
import { getPaddleEnvironment } from "@/lib/paddle";

export const Route = createFileRoute("/")({
  component: Index,
  head: () => ({
    meta: [
      { title: "PrylKollen — Katalogisera ditt hem med AI" },
      { name: "description", content: "Filma rummet, AI:n identifierar dina prylar. Gratis att börja, Pro för 50 kr/mån." },
      { property: "og:title", content: "PrylKollen — Katalogisera ditt hem med AI" },
      { property: "og:description", content: "Filma rummet, AI:n identifierar dina prylar. Gratis att börja." },
    ],
  }),
});

type Item = { name: string; category: string; description: string; image?: string; value?: string };
type DetectedItem = Pick<Item, "name" | "category" | "description">;

function Index() {
  const navigate = useNavigate();
  const { user, loading: authLoading } = useAuth();
  const [isEmbeddedPreview, setIsEmbeddedPreview] = useState(false);
  useEffect(() => {
    setIsEmbeddedPreview(typeof window !== "undefined" && window.self !== window.top);
  }, []);
  const analyze = useServerFn(analyzeFrame);
  const deepDive = useServerFn(deepDiveItem);
  const usageFn = useServerFn(getUsageStatus);
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const itemsRef = useRef<Item[]>([]);
  const busyRef = useRef(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const cameraInputRef = useRef<HTMLInputElement>(null);

  const STORAGE_KEY = "inventering-items-v1";
  const [scanning, setScanning] = useState(false);
  const [items, setItems] = useState<Item[]>([]);
  const [hydrated, setHydrated] = useState(false);
  const [analyzing, setAnalyzing] = useState(false);
  const [frameCount, setFrameCount] = useState(0);
  const [paywallOpen, setPaywallOpen] = useState(false);
  const [usage, setUsage] = useState<{ isSubscribed: boolean; isPastDue: boolean; remaining: number; limit: number } | null>(null);

  // Public landing for unauthenticated visitors (rendered below)

  const fetchUsage = useCallback(async () => {
    const { data } = await supabase.auth.getSession();
    if (!data.session?.access_token) return null;
    try {
      const s = await usageFn({
        data: {
          accessToken: data.session.access_token,
        },
      });
      const next = { isSubscribed: s.isSubscribed, isPastDue: s.isPastDue, remaining: s.remaining, limit: s.limit };
      setUsage(next);
      return next;
    } catch (err) {
      console.warn("usage fetch failed", err);
      return null;
    }
  }, [usageFn]);

  // Initial load
  useEffect(() => {
    if (!user) return;
    void fetchUsage();
  }, [user, fetchUsage]);

  // After Paddle checkout success: poll until webhook has flipped the status
  useEffect(() => {
    if (typeof window === "undefined" || !user) return;
    const params = new URLSearchParams(window.location.search);
    if (params.get("checkout") !== "success") return;

    let cancelled = false;
    let attempts = 0;
    toast.success("Betalningen mottogs! Aktiverar Pro …");
    const tick = async () => {
      if (cancelled) return;
      attempts++;
      const s = await fetchUsage();
      if (s?.isSubscribed) {
        toast.success("Pro är aktiverat 🎉");
        params.delete("checkout");
        const newUrl = window.location.pathname + (params.toString() ? `?${params}` : "");
        window.history.replaceState({}, "", newUrl);
        return;
      }
      if (attempts < 15) setTimeout(tick, 2000);
      else {
        toast.message("Aktivering tar längre tid än vanligt", {
          description: "Ladda om sidan om en stund.",
        });
      }
    };
    void tick();
    return () => { cancelled = true; };
  }, [user, fetchUsage]);

  // Load from localStorage after mount to avoid SSR hydration mismatch
  useEffect(() => {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (raw) setItems(JSON.parse(raw) as Item[]);
    } catch {}
    setHydrated(true);
  }, []);

  useEffect(() => {
    itemsRef.current = items;
    if (hydrated) {
      try {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(items));
      } catch {}
    }
  }, [items, hydrated]);

  const [selectedItem, setSelectedItem] = useState<Item | null>(null);
  const [deepDiveLoading, setDeepDiveLoading] = useState(false);
  const [deepDiveResult, setDeepDiveResult] = useState<string | null>(null);

  const getAccessToken = async () => {
    const { data, error } = await supabase.auth.getSession();
    if (error) {
      throw new Error("Kunde inte läsa din session just nu. Försök igen.");
    }
    if (!data.session?.access_token) {
      throw new Error("Din inloggning tappades när kameran öppnades. Öppna appen igen och försök en gång till.");
    }
    return data.session.access_token;
  };

  useEffect(() => {
    setDeepDiveResult(null);
    setDeepDiveLoading(false);
  }, [selectedItem]);

  const runDeepDive = async () => {
    if (!selectedItem) return;
    setDeepDiveLoading(true);
    setDeepDiveResult(null);
    try {
      const accessToken = await getAccessToken();
      const r = await deepDive({
        data: {
          name: selectedItem.name,
          description: selectedItem.description,
          category: selectedItem.category,
          imageBase64: selectedItem.image,
          accessToken,
        },
      });
      setDeepDiveResult(r.content || "Inget svar.");
    } catch (e) {
      const msg = e instanceof Error ? e.message : "Något gick fel";
      toast.error(msg);
      setDeepDiveResult(null);
    } finally {
      setDeepDiveLoading(false);
    }
  };

  const removeItem = (name: string) => {
    setItems((prev) => prev.filter((i) => i.name !== name));
  };

  const appendDetectedItems = (detected: DetectedItem[], image?: string) => {
    const seen = new Set(itemsRef.current.map((item) => item.name.toLowerCase().trim()));
    const unique = detected.filter((item) => {
      const key = item.name.toLowerCase().trim();
      if (seen.has(key)) return false;
      seen.add(key);
      return true;
    });

    if (!unique.length) return 0;

    const nextItems = [
      ...itemsRef.current,
      ...unique.map((item) => ({ ...item, image })),
    ];

    itemsRef.current = nextItems;
    setItems(nextItems);
    return unique.length;
  };

  const updateUsageRemaining = (remaining?: number | null) => {
    if (typeof remaining === "number") {
      setUsage((u) => (u ? { ...u, remaining } : u));
    }
  };

  const updateItemValue = (name: string, value: string) => {
    const trimmed = value.slice(0, 50);
    setItems((prev) => prev.map((i) => (i.name === name ? { ...i, value: trimmed } : i)));
    setSelectedItem((prev) => (prev && prev.name === name ? { ...prev, value: trimmed } : prev));
  };

  const getCameraErrorMessage = (error: unknown) => {
    if (typeof window !== "undefined" && !window.isSecureContext) {
      return "Livekamera kräver en säker https-länk. Öppna appen via den delade eller publicerade länken.";
    }

    const name = error instanceof DOMException ? error.name : "";

    if (name === "NotAllowedError" || name === "PermissionDeniedError") {
      return "Kameraåtkomst blockerades. Tillåt kameran i mobilens webbläsare och försök igen.";
    }
    if (name === "NotFoundError" || name === "DevicesNotFoundError") {
      return "Ingen kamera hittades på enheten.";
    }
    if (name === "NotReadableError" || name === "TrackStartError") {
      return "Kameran används redan av en annan app. Stäng andra kameraappar och försök igen.";
    }
    if (name === "OverconstrainedError" || name === "ConstraintNotSatisfiedError") {
      return "Kunde inte starta bakre kameran på den här enheten. Prova igen eller använd Ta foto.";
    }

    return "Kunde inte starta kameran på mobilen just nu. Prova igen eller använd Ta foto istället.";
  };

  useEffect(() => {
    return () => {
      stopScanning();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const startScanning = async () => {
    if (isEmbeddedPreview) {
      toast.info("Livekamera fungerar inte i previewn. Använd Ta foto här eller öppna den delade länken i mobilens webbläsare.");
      return;
    }

    if (typeof navigator === "undefined" || !navigator.mediaDevices?.getUserMedia) {
      toast.error("Livekamera stöds inte här. Använd Ta foto istället.");
      return;
    }

    const tryGetStream = async () => {
      const attempts: MediaStreamConstraints[] = [
        { video: { facingMode: { exact: "environment" } }, audio: false },
        { video: { facingMode: "environment" }, audio: false },
        { video: true, audio: false },
      ];
      let lastError: unknown = null;
      for (const constraints of attempts) {
        try {
          return await navigator.mediaDevices.getUserMedia(constraints);
        } catch (err) {
          lastError = err;
          console.warn("getUserMedia attempt failed", constraints, err);
        }
      }
      throw lastError;
    };

    try {
      const stream = await tryGetStream();

      streamRef.current = stream;

      if (videoRef.current) {
        const video = videoRef.current;
        video.muted = true;
        video.defaultMuted = true;
        video.playsInline = true;
        video.autoplay = true;
        video.srcObject = stream;

        try {
          await video.play();
        } catch (playError) {
          console.warn("camera preview play failed", playError);
        }

        if (video.videoWidth === 0) {
          await new Promise<void>((resolve) => {
            let finished = false;
            const finish = () => {
              if (finished) return;
              finished = true;
              video.removeEventListener("loadedmetadata", finish);
              video.removeEventListener("loadeddata", finish);
              video.removeEventListener("canplay", finish);
              resolve();
            };

            video.addEventListener("loadedmetadata", finish, { once: true });
            video.addEventListener("loadeddata", finish, { once: true });
            video.addEventListener("canplay", finish, { once: true });
            window.setTimeout(finish, 1500);
          });
        }
      }

      setScanning(true);
      toast.success("Kamera igång — filma rummet långsamt");
      void captureAndAnalyze();
      intervalRef.current = setInterval(() => {
        void captureAndAnalyze();
      }, 3500);
    } catch (e) {
      console.error("camera start failed", e);
      toast.error(getCameraErrorMessage(e));
    }
  };

  const stopScanning = () => {
    if (intervalRef.current) clearInterval(intervalRef.current);
    intervalRef.current = null;
    streamRef.current?.getTracks().forEach((t) => t.stop());
    streamRef.current = null;
    if (videoRef.current) {
      videoRef.current.onloadedmetadata = null;
      videoRef.current.srcObject = null;
    }
    setScanning(false);
  };

  const captureAndAnalyze = async () => {
    if (busyRef.current) return;
    const video = videoRef.current;
    const canvas = canvasRef.current;
    if (!video || !canvas || video.videoWidth === 0) return;

    busyRef.current = true;
    setAnalyzing(true);
    try {
      const w = 800;
      const h = (video.videoHeight / video.videoWidth) * w;
      canvas.width = w;
      canvas.height = h;
      const ctx = canvas.getContext("2d")!;
      ctx.drawImage(video, 0, 0, w, h);
      const dataUrl = canvas.toDataURL("image/jpeg", 0.7);

      // Smaller thumbnail for storage
      const tw = 480;
      const th = (video.videoHeight / video.videoWidth) * tw;
      const thumbCanvas = document.createElement("canvas");
      thumbCanvas.width = tw;
      thumbCanvas.height = th;
      thumbCanvas.getContext("2d")!.drawImage(video, 0, 0, tw, th);
      const thumb = thumbCanvas.toDataURL("image/jpeg", 0.6);

      setFrameCount((c) => c + 1);

      const existing = itemsRef.current.map((i) => i.name);
      const accessToken = await getAccessToken();
      const result = await analyze({ data: { imageBase64: dataUrl, existing, accessToken } });

      const addedCount = appendDetectedItems(result.items, thumb);
      if (addedCount) {
        toast.success(`+${addedCount} nya föremål`);
      }
      updateUsageRemaining(result.remaining);
    } catch (e: any) {
      console.error(e);
      const msg = e?.message ?? "Analys misslyckades";
      if (typeof msg === "string" && msg.startsWith("PAYWALL")) {
        stopScanning();
        setPaywallOpen(true);
      } else {
        toast.error(msg);
      }
    } finally {
      busyRef.current = false;
      setAnalyzing(false);
    }
  };

  const handlePhotoUpload = async (file: File) => {
    if (busyRef.current) {
      toast.info("En analys pågår redan, vänta lite");
      return;
    }
    busyRef.current = true;
    setAnalyzing(true);
    try {
      const dataUrl: string = await new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => resolve(reader.result as string);
        reader.onerror = reject;
        reader.readAsDataURL(file);
      });

      const img = await new Promise<HTMLImageElement>((resolve, reject) => {
        const i = new Image();
        i.onload = () => resolve(i);
        i.onerror = reject;
        i.src = dataUrl;
      });

      const drawScaled = (maxW: number, quality: number) => {
        const ratio = img.height / img.width;
        const w = Math.min(img.width, maxW);
        const h = w * ratio;
        const c = document.createElement("canvas");
        c.width = w;
        c.height = h;
        c.getContext("2d")!.drawImage(img, 0, 0, w, h);
        return c.toDataURL("image/jpeg", quality);
      };

      const analysisImg = drawScaled(800, 0.7);
      const thumb = drawScaled(480, 0.6);

      toast.info("Analyserar foto…");
      const existing = itemsRef.current.map((i) => i.name);
      const accessToken = await getAccessToken();
      const result = await analyze({ data: { imageBase64: analysisImg, existing, accessToken } });

      const addedCount = appendDetectedItems(result.items, thumb);
      if (addedCount) {
        toast.success(`+${addedCount} nya föremål`);
      } else {
        toast.message("Inga nya föremål hittades i fotot");
      }
      updateUsageRemaining(result.remaining);
    } catch (e: any) {
      console.error(e);
      const msg = e?.message ?? "Kunde inte analysera fotot";
      if (typeof msg === "string" && msg.startsWith("PAYWALL")) {
        setPaywallOpen(true);
      } else {
        toast.error(msg);
      }
    } finally {
      busyRef.current = false;
      setAnalyzing(false);
      if (fileInputRef.current) fileInputRef.current.value = "";
      if (cameraInputRef.current) cameraInputRef.current.value = "";
    }
  };

  // Video upload removed — "Filma" now uses the proven live-camera flow.

  const clearAll = () => {
    setItems([]);
    setFrameCount(0);
  };

  const exportPdf = async () => {
    if (!items.length) return;
    try {
      toast.loading("Skapar PDF…", { id: "pdf" });
      const { jsPDF } = await import("jspdf");
      const doc = new jsPDF({ unit: "pt", format: "a4" });
      const pageW = doc.internal.pageSize.getWidth();
      const pageH = doc.internal.pageSize.getHeight();
      const margin = 40;
      let y = margin;

      const dateStr = new Date().toLocaleDateString("sv-SE");
      doc.setFont("helvetica", "bold");
      doc.setFontSize(20);
      doc.text("Inventering", margin, y);
      y += 22;
      doc.setFont("helvetica", "normal");
      doc.setFontSize(10);
      doc.setTextColor(120);
      doc.text(`Skapad ${dateStr} · ${items.length} föremål`, margin, y);
      doc.setTextColor(0);
      y += 24;

      const grouped = items.reduce<Record<string, Item[]>>((acc, it) => {
        (acc[it.category] ||= []).push(it);
        return acc;
      }, {});
      const cats = Object.keys(grouped).sort();

      const ensureSpace = (needed: number) => {
        if (y + needed > pageH - margin) {
          doc.addPage();
          y = margin;
        }
      };

      for (const cat of cats) {
        ensureSpace(40);
        doc.setFont("helvetica", "bold");
        doc.setFontSize(13);
        doc.text(cat.toUpperCase(), margin, y);
        y += 6;
        doc.setDrawColor(220);
        doc.line(margin, y, pageW - margin, y);
        y += 14;

        for (const it of grouped[cat]) {
          const imgSize = 56;
          const rowH = imgSize + 12;
          ensureSpace(rowH + 8);
          const rowY = y;

          if (it.image) {
            try {
              const fmt = it.image.startsWith("data:image/png") ? "PNG" : "JPEG";
              doc.addImage(it.image, fmt, margin, rowY, imgSize, imgSize, undefined, "FAST");
            } catch {
              // skip image errors
            }
          }
          const textX = margin + imgSize + 12;
          const textW = pageW - margin - textX;

          doc.setFont("helvetica", "bold");
          doc.setFontSize(11);
          const nameLines = doc.splitTextToSize(it.name, textW);
          doc.text(nameLines, textX, rowY + 12);
          let textY = rowY + 12 + nameLines.length * 13;

          if (it.description) {
            doc.setFont("helvetica", "normal");
            doc.setFontSize(9);
            doc.setTextColor(90);
            const descLines = doc.splitTextToSize(it.description, textW);
            doc.text(descLines.slice(0, 3), textX, textY);
            textY += Math.min(descLines.length, 3) * 11;
            doc.setTextColor(0);
          }
          if (it.value) {
            doc.setFont("helvetica", "italic");
            doc.setFontSize(9);
            doc.setTextColor(60);
            doc.text(`Värde: ${it.value}`, textX, textY + 2);
            doc.setTextColor(0);
          }

          y = rowY + rowH;
        }
        y += 8;
      }

      const pages = doc.getNumberOfPages();
      for (let i = 1; i <= pages; i++) {
        doc.setPage(i);
        doc.setFont("helvetica", "normal");
        doc.setFontSize(8);
        doc.setTextColor(150);
        doc.text(`PrylKollen · sida ${i} / ${pages}`, pageW / 2, pageH - 18, { align: "center" });
      }

      doc.save(`inventering-${new Date().toISOString().slice(0, 10)}.pdf`);
      toast.success("PDF nedladdad", { id: "pdf" });
    } catch (e) {
      console.error(e);
      toast.error("Kunde inte skapa PDF", { id: "pdf" });
    }
  };

  const grouped = items.reduce<Record<string, Item[]>>((acc, it) => {
    (acc[it.category] ||= []).push(it);
    return acc;
  }, {});
  const categories = Object.keys(grouped).sort();

  if (authLoading) {
    return <div className="min-h-screen bg-background" />;
  }
  if (!user) {
    return <PublicLanding />;
  }

  return (
    <div className="min-h-screen bg-background">
      <PaymentTestModeBanner />
      <Toaster position="top-center" richColors />
      {usage?.isPastDue && (
        <div className="w-full bg-destructive/10 border-b border-destructive/30 px-4 py-2 text-center text-sm text-destructive">
          Din senaste betalning gick inte igenom.{" "}
          <button onClick={() => setPaywallOpen(true)} className="underline font-medium">
            Uppdatera betalsätt
          </button>
        </div>
      )}
      <div className="mx-auto max-w-6xl px-4 py-8 sm:py-12">
        <header className="mb-8 px-1">
          <div className="flex items-start justify-between gap-3">
            <div>
              <div className="mb-2 inline-flex items-center gap-1.5 rounded-full border bg-card px-2.5 py-1 text-[10px] font-semibold uppercase tracking-widest text-muted-foreground">
                <span className="h-1.5 w-1.5 rounded-full bg-primary" />
                PrylKollen
              </div>
              <h1 className="text-3xl sm:text-4xl font-bold tracking-tight text-foreground">PrylKollen</h1>
              <p className="mt-2 text-sm sm:text-[15px] leading-relaxed text-muted-foreground max-w-prose">
                Filma långsamt runt i rummet. AI:n identifierar föremål och sorterar dem i kategorier.
              </p>
            </div>
            <div className="flex flex-col items-end gap-2">
              {usage && (
                <button
                  onClick={() => setPaywallOpen(true)}
                  className="rounded-full border bg-card px-3 py-1 text-xs font-medium text-muted-foreground hover:text-foreground"
                >
                  {usage.isSubscribed ? (
                    <span className="flex items-center gap-1.5"><Sparkles className="h-3 w-3 text-primary" /> Pro</span>
                  ) : (
                    <span>{usage.remaining}/{usage.limit} gratis kvar</span>
                  )}
                </button>
              )}
              <Button
                variant="ghost"
                size="sm"
                onClick={async () => {
                  await supabase.auth.signOut();
                  navigate({ to: "/login" });
                }}
                className="text-muted-foreground"
              >
                <LogOut className="mr-1.5 h-3.5 w-3.5" /> Logga ut
              </Button>
            </div>
          </div>
        </header>

        <div className="grid gap-6 lg:grid-cols-2">
          <Card className="overflow-hidden p-0 rounded-3xl border-border/70 shadow-sm">
            <div className="relative aspect-[4/3] bg-muted">
              <video
                ref={videoRef}
                autoPlay
                playsInline
                muted
                className="h-full w-full object-cover"
              />
              {!scanning && (
                <div className="absolute inset-0 flex flex-col items-center justify-center gap-3">
                  <div className="flex h-16 w-16 items-center justify-center rounded-full bg-background/80 shadow-sm backdrop-blur-md">
                    <Camera className="h-7 w-7 text-muted-foreground" strokeWidth={1.5} />
                  </div>
                  <span className="text-[11px] font-medium uppercase tracking-widest text-muted-foreground">
                    Kameran är inte aktiv
                  </span>
                </div>
              )}
              {analyzing && (
                <div className="absolute right-3 top-3 flex items-center gap-2 rounded-full bg-background/80 px-3 py-1 text-xs backdrop-blur">
                  <Loader2 className="h-3 w-3 animate-spin" />
                  Analyserar…
                </div>
              )}
              {scanning && (
                <div className="absolute left-3 top-3 flex items-center gap-2 rounded-full bg-destructive/90 px-3 py-1 text-xs font-medium text-destructive-foreground">
                  <span className="h-2 w-2 animate-pulse rounded-full bg-white" />
                  LIVE
                </div>
              )}
            </div>
            <canvas ref={canvasRef} className="hidden" />
            <input
              ref={fileInputRef}
              type="file"
              accept="image/*"
              className="hidden"
              onChange={(e) => {
                const f = e.target.files?.[0];
                if (f) handlePhotoUpload(f);
              }}
            />
            <input
              ref={cameraInputRef}
              type="file"
              accept="image/*"
              capture={isEmbeddedPreview ? undefined : "environment"}
              className="hidden"
              onChange={(e) => {
                const f = e.target.files?.[0];
                if (f) handlePhotoUpload(f);
              }}
            />
            <div className="space-y-3 p-5">
              <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                {!scanning ? (
                  <Button onClick={startScanning} size="lg" className="rounded-2xl">
                    <Camera className="mr-2 h-4 w-4" />
                    Filma rummet
                  </Button>
                ) : (
                  <Button onClick={stopScanning} size="lg" variant="secondary" className="rounded-2xl">
                    <CameraOff className="mr-2 h-4 w-4" />
                    Stoppa
                  </Button>
                )}
                <Button
                  onClick={() => {
                    if (isEmbeddedPreview) {
                      fileInputRef.current?.click();
                      return;
                    }
                    cameraInputRef.current?.click();
                  }}
                  disabled={analyzing}
                  size="lg"
                  variant="secondary"
                  className="rounded-2xl"
                >
                  <Camera className="mr-2 h-4 w-4" />
                  Ta foto
                </Button>
              </div>

              <Button
                onClick={captureAndAnalyze}
                disabled={!scanning || analyzing}
                size="lg"
                variant="outline"
                className="w-full rounded-2xl"
              >
                Analysera nu
              </Button>

              {isEmbeddedPreview && !scanning && (
                <p className="text-center text-xs text-muted-foreground">
                  Livekamera kräver att appen öppnas direkt i mobilens webbläsare. I previewn kan du använda <span className="font-medium text-foreground">Ta foto</span> eller <span className="font-medium text-foreground">Filma</span>.
                </p>
              )}

              <div className="grid grid-cols-2 gap-2 pt-1">
                <Button
                  onClick={() => fileInputRef.current?.click()}
                  disabled={analyzing}
                  variant="ghost"
                  className="rounded-xl text-muted-foreground hover:text-foreground"
                >
                  <ImagePlus className="mr-2 h-4 w-4" />
                  Ladda upp foto
                </Button>
                <Button
                  onClick={() => {
                    if (!items.length) return;
                    if (confirm(`Radera alla ${items.length} föremål? Detta kan inte ångras.`)) {
                      clearAll();
                      toast.success("Inventarielistan rensad");
                    }
                  }}
                  disabled={!items.length}
                  variant="ghost"
                  className="rounded-xl text-destructive/80 hover:bg-destructive/5 hover:text-destructive"
                >
                  <Trash2 className="mr-2 h-4 w-4" />
                  Rensa allt
                </Button>
              </div>
            </div>
            <div className="border-t bg-muted/40 px-4 py-3 text-center text-[11px] font-medium uppercase tracking-widest text-muted-foreground">
              {frameCount} bildrutor analyserade <span className="mx-1 text-border">·</span> {items.length} föremål hittade
            </div>
          </Card>

          <Card className="rounded-3xl border-border/70 p-5 shadow-sm sm:p-6">
            <div className="mb-5 flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-primary text-primary-foreground">
                  <Package className="h-4 w-4" />
                </div>
                <h2 className="text-lg font-bold tracking-tight">Inventarielista</h2>
              </div>
              <div className="flex gap-1">
                <Button onClick={exportPdf} size="icon" variant="ghost" disabled={!items.length} className="rounded-full text-muted-foreground hover:text-foreground" title="Ladda ner som PDF">
                  <Download className="h-4 w-4" />
                </Button>
                <Button onClick={clearAll} size="icon" variant="ghost" disabled={!items.length} className="rounded-full text-muted-foreground hover:text-destructive">
                  <Trash2 className="h-4 w-4" />
                </Button>
              </div>
            </div>

            {items.length === 0 ? (
              <div className="flex min-h-[180px] flex-col items-center justify-center gap-3 rounded-2xl border border-dashed bg-muted/40 p-8 text-center">
                <div className="flex h-12 w-12 items-center justify-center rounded-xl border bg-card shadow-sm">
                  <Package className="h-5 w-5 text-muted-foreground/60" strokeWidth={1.5} />
                </div>
                <p className="max-w-[220px] text-sm font-medium leading-relaxed text-muted-foreground">
                  Inga föremål ännu — starta kameran och börja filma för att bygga din lista.
                </p>
              </div>
            ) : (
              <div className="max-h-[60vh] space-y-6 overflow-y-auto pr-1">
                {categories.map((cat) => (
                  <div key={cat}>
                    <div className="mb-2 flex items-center gap-2">
                      <h3 className="text-sm font-semibold uppercase tracking-wider text-muted-foreground">{cat}</h3>
                      <Badge variant="secondary" className="rounded-full">{grouped[cat].length}</Badge>
                    </div>
                    <ul className="space-y-2">
                      {grouped[cat].map((it, i) => (
                        <li key={cat + i} className="group flex items-center gap-3 rounded-2xl border border-border/70 bg-card p-2.5 transition-colors hover:bg-accent/40">
                          <button
                            onClick={() => setSelectedItem(it)}
                            className="flex flex-1 items-center gap-3 text-left min-w-0"
                          >
                            {it.image ? (
                              <img
                                src={it.image}
                                alt={it.name}
                                className="h-12 w-12 flex-shrink-0 rounded-xl border object-cover"
                              />
                            ) : (
                              <div className="flex h-12 w-12 flex-shrink-0 items-center justify-center rounded-xl bg-muted">
                                <ImageOff className="h-4 w-4 text-muted-foreground" />
                              </div>
                            )}
                            <div className="min-w-0 flex-1">
                              <div className="truncate text-sm font-semibold">{it.name}</div>
                              {it.description && (
                                <div className="mt-0.5 line-clamp-1 text-xs text-muted-foreground">{it.description}</div>
                              )}
                            </div>
                          </button>
                          <button
                            onClick={() => removeItem(it.name)}
                            className="rounded-full p-1.5 text-muted-foreground/60 opacity-0 transition-opacity hover:bg-destructive/10 hover:text-destructive group-hover:opacity-100"
                            aria-label="Ta bort"
                          >
                            <Trash2 className="h-3.5 w-3.5" />
                          </button>
                        </li>
                      ))}
                    </ul>
                  </div>
                ))}
              </div>
            )}
          </Card>
        </div>
      </div>


      <Dialog open={!!selectedItem} onOpenChange={(o) => !o && setSelectedItem(null)}>
        <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{selectedItem?.name}</DialogTitle>
            {selectedItem?.description && (
              <DialogDescription>{selectedItem.description}</DialogDescription>
            )}
          </DialogHeader>
          {selectedItem?.category && (
            <div>
              <Badge variant="secondary">{selectedItem.category}</Badge>
            </div>
          )}
          {selectedItem?.image ? (
            <img
              src={selectedItem.image}
              alt={selectedItem.name}
              className="w-full rounded-md border"
            />
          ) : (
            <div className="flex h-48 flex-col items-center justify-center gap-2 rounded-md border bg-muted text-sm text-muted-foreground p-4 text-center">
              <ImageOff className="h-6 w-6" />
              <p>Ingen bild sparad för detta föremål.</p>
              <p className="text-xs">Föremål som upptäcks från och med nu sparar en bild automatiskt.</p>
            </div>
          )}

          {selectedItem && (
            <div className="space-y-1.5">
              <Label htmlFor="item-value" className="text-sm">Värde (SEK)</Label>
              <Input
                id="item-value"
                type="text"
                inputMode="numeric"
                placeholder="t.ex. 4500"
                maxLength={50}
                value={selectedItem.value ?? ""}
                onChange={(e) => updateItemValue(selectedItem.name, e.target.value)}
              />
              <p className="text-xs text-muted-foreground">Fyll i det korrekta värdet om du vet det — annars är AI:ns uppskattning bara en gissning.</p>
            </div>
          )}

          {!deepDiveResult && (
            <Button onClick={runDeepDive} disabled={deepDiveLoading} className="w-full">
              {deepDiveLoading ? (
                <><Loader2 className="mr-2 h-4 w-4 animate-spin" /> Djupdyker…</>
              ) : (
                <><Sparkles className="mr-2 h-4 w-4" /> Djupdyk i föremålet</>
              )}
            </Button>
          )}

          {deepDiveResult && (
            <div className="rounded-md border bg-muted/40 p-4 space-y-2 text-sm leading-relaxed whitespace-pre-wrap">
              {deepDiveResult}
              <div className="pt-2">
                <Button
                  size="sm"
                  variant="ghost"
                  onClick={() => {
                    setDeepDiveResult(null);
                    runDeepDive();
                  }}
                >
                  Kör igen
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {user && (
        <PaywallDialog
          open={paywallOpen}
          onOpenChange={setPaywallOpen}
          userId={user.id}
          userEmail={user.email}
          isSubscribed={!!usage?.isSubscribed}
        />
      )}
    </div>
  );
}

import { createFileRoute, useNavigate, Link } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { lovable } from "@/integrations/lovable";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card } from "@/components/ui/card";
import { toast, Toaster } from "sonner";
import { Loader2 } from "lucide-react";
import { SiteFooter } from "@/components/SiteFooter";

export const Route = createFileRoute("/login")({
  component: LoginPage,
  head: () => ({
    meta: [
      { title: "Logga in — PrylKollen" },
      { name: "description", content: "Logga in på PrylKollen för att börja inventera." },
    ],
  }),
});

function LoginPage() {
  const navigate = useNavigate();
  const [mode, setMode] = useState<"signin" | "signup">("signin");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const googleAutoStartRef = useRef(false);

  const syncSession = async () => {
    const { data } = await supabase.auth.getSession();
    if (data.session) {
      navigate({ to: "/" });
      return true;
    }
    return false;
  };

  useEffect(() => {
    const { data: sub } = supabase.auth.onAuthStateChange((_event, session) => {
      if (session) navigate({ to: "/" });
    });
    const handleVisibilityChange = () => {
      if (document.visibilityState === "visible") {
        void syncSession();
      }
    };
    const handlePageShow = () => {
      void syncSession();
    };

    void syncSession();
    document.addEventListener("visibilitychange", handleVisibilityChange);
    window.addEventListener("pageshow", handlePageShow);

    return () => {
      sub.subscription.unsubscribe();
      document.removeEventListener("visibilitychange", handleVisibilityChange);
      window.removeEventListener("pageshow", handlePageShow);
    };
  }, [navigate]);

  useEffect(() => {
    if (typeof window === "undefined" || googleAutoStartRef.current) return;

    const params = new URLSearchParams(window.location.search);
    const shouldStartGoogle = params.get("oauth") === "google";
    const isEmbeddedPreview = window.self !== window.top;

    if (shouldStartGoogle && !isEmbeddedPreview) {
      googleAutoStartRef.current = true;
      void handleGoogle(true);
    }
  }, []);

  const handleEmail = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      if (mode === "signup") {
        const { error } = await supabase.auth.signUp({
          email,
          password,
          options: { emailRedirectTo: window.location.origin },
        });
        if (error) throw error;
        toast.success("Konto skapat! Kolla din e-post för att verifiera.");
      } else {
        const { error } = await supabase.auth.signInWithPassword({ email, password });
        if (error) throw error;
        navigate({ to: "/" });
      }
    } catch (err: any) {
      toast.error(err?.message || "Något gick fel");
    } finally {
      setLoading(false);
    }
  };

  const handleGoogle = async (skipPreviewFallback = false) => {
    setLoading(true);

    try {
      const isEmbeddedPreview = typeof window !== "undefined" && window.self !== window.top;

      if (isEmbeddedPreview && !skipPreviewFallback) {
        const loginUrl = new URL(window.location.href);
        loginUrl.searchParams.set("oauth", "google");
        window.open(loginUrl.toString(), "_blank", "noopener,noreferrer");
        toast.info("Google-inloggningen öppnades i en ny flik.");
        setLoading(false);
        return;
      }

      const result = await lovable.auth.signInWithOAuth("google", {
        redirect_uri: window.location.origin,
      });

      if (result.redirected) return;

      const { data } = await supabase.auth.getSession();
      if (data.session) {
        navigate({ to: "/" });
        return;
      }

      if (result.error) {
        toast.error(result.error.message || "Kunde inte logga in med Google");
        setLoading(false);
        return;
      }

      navigate({ to: "/" });
    } catch (error) {
      const { data } = await supabase.auth.getSession();
      if (data.session) {
        navigate({ to: "/" });
        return;
      }

      toast.error(error instanceof Error ? error.message : "Kunde inte logga in med Google");
      setLoading(false);
    }
  };

  const handleApple = async () => {
    setLoading(true);
    try {
      const result = await lovable.auth.signInWithOAuth("apple", {
        redirect_uri: window.location.origin,
      });
      if (result.redirected) return;
      const { data } = await supabase.auth.getSession();
      if (data.session) {
        navigate({ to: "/" });
        return;
      }
      if (result.error) {
        toast.error(result.error.message || "Kunde inte logga in med Apple");
        setLoading(false);
        return;
      }
      navigate({ to: "/" });
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Kunde inte logga in med Apple");
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-background flex flex-col">
      <Toaster position="top-center" richColors />
      <div className="flex-1 flex items-center justify-center px-4 py-10">
      <Card className="w-full max-w-md p-8 rounded-3xl shadow-sm">
        <div className="mb-6 text-center">
          <Link to="/" className="inline-block text-xs font-semibold uppercase tracking-widest text-muted-foreground hover:text-foreground">
            ← PrylKollen
          </Link>
          <h1 className="mt-3 text-2xl font-bold">{mode === "signin" ? "Välkommen tillbaka" : "Skapa konto"}</h1>
          <p className="mt-1 text-sm text-muted-foreground">
            {mode === "signin" ? "Logga in för att fortsätta inventera." : "5 gratis fotoanalyser ingår."}
          </p>
        </div>

        <Button onClick={() => void handleGoogle()} disabled={loading} variant="outline" className="w-full rounded-2xl">
          Fortsätt med Google
        </Button>
        <Button onClick={() => void handleApple()} disabled={loading} variant="outline" className="mt-2 w-full rounded-2xl">
          Fortsätt med Apple
        </Button>

        <div className="my-5 flex items-center gap-3">
          <div className="h-px flex-1 bg-border" />
          <span className="text-xs uppercase tracking-widest text-muted-foreground">eller</span>
          <div className="h-px flex-1 bg-border" />
        </div>

        <form onSubmit={handleEmail} className="space-y-3">
          <div className="space-y-1.5">
            <Label htmlFor="email">E-post</Label>
            <Input id="email" type="email" required value={email} onChange={(e) => setEmail(e.target.value)} />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="password">Lösenord</Label>
            <Input id="password" type="password" required minLength={6} value={password} onChange={(e) => setPassword(e.target.value)} />
          </div>
          <Button type="submit" disabled={loading} className="w-full rounded-2xl">
            {loading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
            {mode === "signin" ? "Logga in" : "Skapa konto"}
          </Button>
        </form>

        <button
          type="button"
          onClick={() => setMode(mode === "signin" ? "signup" : "signin")}
          className="mt-5 w-full text-center text-sm text-muted-foreground hover:text-foreground"
        >
          {mode === "signin" ? "Inget konto? Skapa ett" : "Har du redan konto? Logga in"}
        </button>
      </Card>
      </div>
      <SiteFooter />
    </div>
  );
}

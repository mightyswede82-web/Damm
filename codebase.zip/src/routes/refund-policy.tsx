import { createFileRoute, Link } from "@tanstack/react-router";
import { SiteFooter } from "@/components/SiteFooter";

export const Route = createFileRoute("/refund-policy")({
  component: RefundPage,
  head: () => ({
    meta: [
      { title: "Återbetalningspolicy — PrylKollen" },
      { name: "description", content: "30 dagars öppet köp på PrylKollen Pro." },
    ],
  }),
});

function RefundPage() {
  return (
    <div className="min-h-screen bg-background flex flex-col">
      <main className="mx-auto w-full max-w-3xl flex-1 px-4 py-12 sm:py-16">
        <Link to="/" className="text-xs font-semibold uppercase tracking-widest text-muted-foreground hover:text-foreground">
          ← PrylKollen
        </Link>
        <h1 className="mt-4 text-3xl font-bold tracking-tight">Återbetalningspolicy</h1>
        <p className="mt-2 text-sm text-muted-foreground">Senast uppdaterad: {new Date().toLocaleDateString("sv-SE")}</p>

        <div className="prose prose-sm mt-8 max-w-none text-foreground/90 [&_h2]:mt-8 [&_h2]:text-lg [&_h2]:font-semibold [&_p]:mt-3 [&_p]:leading-relaxed">
          <h2>30 dagars öppet köp</h2>
          <p>
            Vi erbjuder 30 dagars öppet köp på PrylKollen Pro. Är du inte nöjd kan du begära full återbetalning inom 30 dagar
            från köpdatumet — utan att ange skäl.
          </p>

          <h2>Så begär du återbetalning</h2>
          <p>
            Återbetalningar hanteras av vår betalleverantör Paddle. Besök{" "}
            <a className="underline" href="https://paddle.net" target="_blank" rel="noopener noreferrer">paddle.net</a>{" "}
            och logga in med den e-postadress du använde vid köpet för att begära återbetalning. Du kan även kontakta vår
            support i appen så hjälper vi dig vidare.
          </p>

          <h2>Pågående prenumerationer</h2>
          <p>
            Du kan när som helst säga upp din Pro-prenumeration från ditt konto eller via Paddles kundportal. Uppsägning gör
            att förnyelser stoppas — du behåller åtkomsten resten av den period du redan betalat för.
          </p>

          <h2>Behandlingstid</h2>
          <p>
            Godkända återbetalningar behandlas av Paddle och syns normalt på ditt kort eller bankkonto inom 5–10 bankdagar.
          </p>

          <h2>Kontakt</h2>
          <p>
            Drivs av Lindgren. Vid frågor om återbetalningar, kontakta supporten i appen eller{" "}
            <a className="underline" href="https://paddle.net" target="_blank" rel="noopener noreferrer">paddle.net</a>.
          </p>
        </div>
      </main>
      <SiteFooter />
    </div>
  );
}

import { createFileRoute, Link } from "@tanstack/react-router";
import { SiteFooter } from "@/components/SiteFooter";

export const Route = createFileRoute("/privacy")({
  component: PrivacyPage,
  head: () => ({
    meta: [
      { title: "Integritetspolicy — PrylKollen" },
      { name: "description", content: "Hur Lindgren hanterar dina personuppgifter i PrylKollen." },
    ],
  }),
});

function PrivacyPage() {
  return (
    <div className="min-h-screen bg-background flex flex-col">
      <main className="mx-auto w-full max-w-3xl flex-1 px-4 py-12 sm:py-16">
        <Link to="/" className="text-xs font-semibold uppercase tracking-widest text-muted-foreground hover:text-foreground">
          ← PrylKollen
        </Link>
        <h1 className="mt-4 text-3xl font-bold tracking-tight">Integritetspolicy</h1>
        <p className="mt-2 text-sm text-muted-foreground">Senast uppdaterad: {new Date().toLocaleDateString("sv-SE")}</p>

        <div className="prose prose-sm mt-8 max-w-none text-foreground/90 [&_h2]:mt-8 [&_h2]:text-lg [&_h2]:font-semibold [&_p]:mt-3 [&_p]:leading-relaxed [&_ul]:mt-3 [&_ul]:list-disc [&_ul]:pl-5 [&_li]:mt-1">
          <h2>1. Personuppgiftsansvarig</h2>
          <p>
            Lindgren ("vi", "oss") är personuppgiftsansvarig för behandlingen av dina personuppgifter i tjänsten PrylKollen.
            Kontakta oss via supporten i appen vid frågor om dina uppgifter.
          </p>

          <h2>2. Vilka uppgifter vi samlar in</h2>
          <ul>
            <li><strong>Kontouppgifter:</strong> e-postadress, lösenord (krypterat) eller Google-ID vid inloggning.</li>
            <li><strong>Användargenererat innehåll:</strong> bilder du laddar upp eller tar i appen samt uppgifter du sparar om dina föremål.</li>
            <li><strong>Användningsdata:</strong> antal fotoanalyser, prenumerationsstatus, tidsstämplar.</li>
            <li><strong>Tekniska uppgifter:</strong> IP-adress, enhets- och webbläsarinformation, loggar.</li>
            <li><strong>Supportkommunikation:</strong> meddelanden du skickar till oss.</li>
          </ul>
          <p>
            Betalningsuppgifter (kortnummer m.m.) hanteras direkt av vår betalleverantör Paddle och behandlas inte av oss.
          </p>

          <h2>3. Ändamål och rättslig grund</h2>
          <ul>
            <li>Tillhandahålla och underhålla Tjänsten — <em>fullgörande av avtal</em>.</li>
            <li>Hantera ditt konto, prenumerationer och support — <em>fullgörande av avtal</em>.</li>
            <li>Förbättra Tjänsten och förebygga missbruk/bedrägeri — <em>berättigat intresse</em>.</li>
            <li>Skicka väsentliga driftsmeddelanden — <em>berättigat intresse</em>.</li>
            <li>Uppfylla rättsliga skyldigheter (t.ex. bokföring) — <em>rättslig förpliktelse</em>.</li>
          </ul>

          <h2>4. AI-behandling</h2>
          <p>
            Bilder du analyserar skickas till en AI-leverantör (via Lovable AI) för att identifiera föremål. Bilderna används
            inte för att träna externa modeller och raderas hos AI-leverantören efter behandling.
          </p>

          <h2>5. Mottagare av uppgifter</h2>
          <ul>
            <li>Tjänsteleverantörer (hosting, databas, autentisering, AI-bearbetning).</li>
            <li>Paddle.com som Merchant of Record för försäljning, prenumerationshantering, betalningar, skatt och fakturering.</li>
            <li>Professionella rådgivare (juridik, redovisning) vid behov.</li>
            <li>Myndigheter när lag kräver det.</li>
          </ul>

          <h2>6. Internationella överföringar</h2>
          <p>
            Vissa leverantörer kan behandla data utanför EES. I sådana fall säkerställer vi lämpliga skyddsåtgärder såsom
            EU-kommissionens standardavtalsklausuler eller adekvansbeslut.
          </p>

          <h2>7. Lagringstid</h2>
          <p>
            Vi sparar dina uppgifter så länge ditt konto är aktivt. Vid radering tas konto- och innehållsdata bort inom
            rimlig tid, förutom uppgifter som krävs enligt lag (t.ex. bokföringsdata i upp till 7 år).
          </p>

          <h2>8. Dina rättigheter (GDPR)</h2>
          <ul>
            <li>Tillgång till dina uppgifter</li>
            <li>Rättelse av felaktiga uppgifter</li>
            <li>Radering ("rätten att bli bortglömd")</li>
            <li>Begränsning av behandling</li>
            <li>Dataportabilitet</li>
            <li>Invändning mot behandling baserad på berättigat intresse</li>
            <li>Återkalla samtycke när behandling baseras på samtycke</li>
            <li>Klaga till Integritetsskyddsmyndigheten (IMY)</li>
          </ul>
          <p>Vi svarar normalt på begäran inom en månad.</p>

          <h2>9. Säkerhet</h2>
          <p>
            Vi vidtar lämpliga tekniska och organisatoriska åtgärder för att skydda dina uppgifter, inklusive kryptering vid
            överföring och lagring samt åtkomstkontroller.
          </p>

          <h2>10. Cookies</h2>
          <p>
            Vi använder endast nödvändiga cookies för inloggning och drift av Tjänsten. Vi använder inte spårnings- eller
            marknadsföringscookies.
          </p>

          <h2>11. Ändringar</h2>
          <p>Vi kan uppdatera denna policy. Väsentliga ändringar meddelas via Tjänsten eller e-post.</p>
        </div>
      </main>
      <SiteFooter />
    </div>
  );
}

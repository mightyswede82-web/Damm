import { createFileRoute, Link } from "@tanstack/react-router";
import { SiteFooter } from "@/components/SiteFooter";
import { Button } from "@/components/ui/button";
import { Check, Sparkles } from "lucide-react";

export const Route = createFileRoute("/pricing")({
  component: PricingPage,
  head: () => ({
    meta: [
      { title: "Pris — PrylKollen" },
      { name: "description", content: "PrylKollen är gratis att börja med. Pro kostar 50 kr/mån för obegränsade fotoanalyser." },
      { property: "og:title", content: "Pris — PrylKollen" },
      { property: "og:description", content: "Gratis att börja. Pro 50 kr/mån." },
    ],
  }),
});

function PricingPage() {
  return (
    <div className="min-h-screen bg-background flex flex-col">
      <header className="border-b">
        <div className="mx-auto flex max-w-6xl items-center justify-between px-4 py-4">
          <Link to="/" className="text-sm font-semibold tracking-tight">PrylKollen</Link>
          <Link to="/login" className="text-sm text-muted-foreground hover:text-foreground">Logga in</Link>
        </div>
      </header>

      <main className="mx-auto w-full max-w-4xl flex-1 px-4 py-12 sm:py-16">
        <div className="text-center">
          <h1 className="text-4xl font-bold tracking-tight sm:text-5xl">Enkel prissättning</h1>
          <p className="mt-3 text-base text-muted-foreground">Börja gratis. Uppgradera när du vill ha mer.</p>
        </div>

        <div className="mt-10 grid gap-5 sm:grid-cols-2">
          <div className="rounded-3xl border bg-card p-6 shadow-sm">
            <h2 className="text-lg font-semibold">Gratis</h2>
            <div className="mt-2 flex items-baseline gap-1">
              <span className="text-4xl font-bold">0 kr</span>
              <span className="text-sm text-muted-foreground">/mån</span>
            </div>
            <p className="mt-1 text-sm text-muted-foreground">Perfekt för att testa.</p>
            <ul className="mt-5 space-y-2 text-sm">
              <li className="flex items-center gap-2"><Check className="h-4 w-4 text-primary" /> 5 fotoanalyser totalt</li>
              <li className="flex items-center gap-2"><Check className="h-4 w-4 text-primary" /> AI-identifiering av föremål</li>
              <li className="flex items-center gap-2"><Check className="h-4 w-4 text-primary" /> Sparas lokalt på din enhet</li>
            </ul>
            <Button asChild variant="outline" className="mt-6 w-full rounded-2xl">
              <Link to="/login">Skapa konto</Link>
            </Button>
          </div>

          <div className="rounded-3xl border-2 border-primary bg-card p-6 shadow-md">
            <div className="flex items-center justify-between">
              <h2 className="flex items-center gap-1.5 text-lg font-semibold"><Sparkles className="h-4 w-4 text-primary" /> Pro</h2>
              <span className="rounded-full bg-primary/10 px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wider text-primary">Populärast</span>
            </div>
            <div className="mt-2 flex items-baseline gap-1">
              <span className="text-4xl font-bold">50 kr</span>
              <span className="text-sm text-muted-foreground">/mån</span>
            </div>
            <p className="mt-1 text-sm text-muted-foreground">För dig som vill katalogisera hela hemmet i lugn och ro.</p>
            <ul className="mt-5 space-y-2 text-sm">
              <li className="flex items-center gap-2"><Check className="h-4 w-4 text-primary" /> Obegränsade fotoanalyser</li>
              <li className="flex items-center gap-2"><Check className="h-4 w-4 text-primary" /> Djupdyk i varje föremål</li>
              <li className="flex items-center gap-2"><Check className="h-4 w-4 text-primary" /> 30 dagars öppet köp</li>
              <li className="flex items-center gap-2"><Check className="h-4 w-4 text-primary" /> Avsluta när du vill</li>
            </ul>
            <Button asChild className="mt-6 w-full rounded-2xl">
              <Link to="/login">Kom igång</Link>
            </Button>
          </div>
        </div>

        <p className="mt-8 text-center text-xs text-muted-foreground">
          Betalningar hanteras av vår återförsäljare Paddle. Se{" "}
          <Link to="/refund-policy" className="underline">återbetalningspolicy</Link> och{" "}
          <Link to="/terms" className="underline">villkor</Link>.
        </p>
      </main>

      <SiteFooter />
    </div>
  );
}

import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { gatewayFetch, getPaddleClient, type PaddleEnv } from "./paddle.server";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { supabaseAdmin } from "@/integrations/supabase/client.server";

function getServerPaddleEnvironment(): PaddleEnv {
  const token = import.meta.env.VITE_PAYMENTS_CLIENT_TOKEN as string | undefined;
  return token?.startsWith("test_") ? "sandbox" : "live";
}

export const resolvePaddlePrice = createServerFn({ method: "GET" })
  .inputValidator((d: { priceId: string; environment: PaddleEnv }) => d)
  .handler(async ({ data }) => {
    const response = await gatewayFetch(
      data.environment,
      `/prices?external_id=${encodeURIComponent(data.priceId)}&status=active`,
    );
    const result = await response.json();
    const active = (result.data ?? []).filter((p: any) => p.status === "active");
    if (!active.length) {
      console.error("resolvePaddlePrice: no active price", {
        priceId: data.priceId,
        environment: data.environment,
        rawCount: result.data?.length ?? 0,
      });
      throw new Error(
        data.environment === "live"
          ? "Betalningen är inte aktiv ännu. Försök igen om en stund."
          : "Pris hittades inte i testläget.",
      );
    }
    return active[0].id as string;
  });

export const getCustomerPortalUrl = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { userId } = context;
    const env = getServerPaddleEnvironment();
    const { data: sub } = await supabaseAdmin
      .from("subscriptions")
      .select("paddle_customer_id, paddle_subscription_id, environment, status")
      .eq("user_id", userId)
      .eq("environment", env)
      .in("status", ["active", "trialing", "past_due", "paused", "canceled"])
      .order("created_at", { ascending: false })
      .limit(1)
      .maybeSingle();

    if (!sub) throw new Error("Ingen prenumeration hittades");

    const paddle = getPaddleClient(sub.environment as PaddleEnv);
    const session = await paddle.customerPortalSessions.create(
      sub.paddle_customer_id as string,
      [sub.paddle_subscription_id as string],
    );
    return { url: session.urls.general.overview };
  });

export const getUsageStatus = createServerFn({ method: "GET" })
  .inputValidator(
    z.object({
      accessToken: z.string().min(1).optional(),
    }),
  )
  .handler(async ({ data }) => {
    const FREE_LIMIT = 5;

    const fallback = {
      authenticated: false,
      isSubscribed: false,
      isPastDue: false,
      used: 0,
      remaining: FREE_LIMIT,
      limit: FREE_LIMIT,
    };

    if (!data.accessToken) {
      return fallback;
    }

    const {
      data: { user },
      error: authError,
    } = await supabaseAdmin.auth.getUser(data.accessToken);

    if (authError || !user) {
      console.warn("getUsageStatus auth fallback", authError?.message ?? "missing user");
      return fallback;
    }

    const [{ data: usage, error: usageError }, { data: sub, error: subError }] = await Promise.all([
      supabaseAdmin
        .from("photo_usage")
        .select("count")
        .eq("user_id", user.id)
        .maybeSingle(),
      supabaseAdmin
        .from("subscriptions")
        .select("status, current_period_end")
        .eq("user_id", user.id)
        .eq("environment", getServerPaddleEnvironment())
        .order("created_at", { ascending: false })
        .limit(1)
        .maybeSingle(),
    ]);

    if (usageError || subError) {
      console.error("getUsageStatus query fallback", {
        usageError: usageError?.message ?? null,
        subError: subError?.message ?? null,
      });
      return { ...fallback, authenticated: true };
    }

    const isActive: boolean = !!sub && (
      (["active", "trialing", "past_due"].includes(sub.status as string) &&
        (!sub.current_period_end || new Date(sub.current_period_end as string) > new Date())) ||
      (sub.status === "canceled" && !!sub.current_period_end && new Date(sub.current_period_end as string) > new Date())
    );

    const used = (usage?.count as number) ?? 0;
    const isPastDue = !!sub && sub.status === "past_due";
    return {
      authenticated: true,
      isSubscribed: isActive,
      isPastDue,
      used,
      remaining: Math.max(0, FREE_LIMIT - used),
      limit: FREE_LIMIT,
    };
  });

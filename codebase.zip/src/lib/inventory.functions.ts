import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { supabaseAdmin } from "@/integrations/supabase/client.server";

const FREE_LIMIT = 5;
// ~1.5 MB base64 (~1.1 MB decoded) — generous headroom for ~800px JPEGs
const MAX_IMAGE_BASE64 = 1_500_000;

function getServerPaddleEnvironment(): "sandbox" | "live" {
  const token = import.meta.env.VITE_PAYMENTS_CLIENT_TOKEN as string | undefined;
  return token?.startsWith("test_") ? "sandbox" : "live";
}

const InputSchema = z.object({
  imageBase64: z
    .string()
    .min(100)
    .max(MAX_IMAGE_BASE64, "Bilden är för stor. Försök igen med en mindre bild.")
    .refine((v) => v.startsWith("data:image/"), {
      message: "Endast base64 data-URL (data:image/…) accepteras",
    }),
  existing: z.array(z.string().max(200)).max(500).optional(),
  accessToken: z.string().min(1).optional(),
});

const ItemSchema = z.object({
  name: z.string(),
  category: z.string(),
  description: z.string().optional().default(""),
});

export const analyzeFrame = createServerFn({ method: "POST" })
  .inputValidator((d) => InputSchema.parse(d))
  .handler(async ({ data }) => {
    const apiKey = process.env.LOVABLE_API_KEY;
    if (!apiKey) throw new Error("LOVABLE_API_KEY saknas");

    if (!data.accessToken) {
      throw new Error("Din inloggning kunde inte verifieras efter kameran. Försök igen.");
    }

    const {
      data: { user },
      error: authError,
    } = await supabaseAdmin.auth.getUser(data.accessToken);

    if (authError || !user) {
      console.warn("analyzeFrame auth failed", authError?.message ?? "missing user");
      throw new Error("Din inloggning tappades när kameran öppnades. Öppna appen igen och försök en gång till.");
    }

    const userId = user.id;

    // Check subscription
    const { data: sub } = await supabaseAdmin
      .from("subscriptions")
      .select("status, current_period_end")
      .eq("user_id", userId)
      .eq("environment", getServerPaddleEnvironment())
      .order("created_at", { ascending: false })
      .limit(1)
      .maybeSingle();

    const isActive = !!sub && (
      (["active", "trialing", "past_due"].includes(sub.status as string) &&
        (!sub.current_period_end || new Date(sub.current_period_end as string) > new Date())) ||
      (sub.status === "canceled" && sub.current_period_end && new Date(sub.current_period_end as string) > new Date())
    );

    // Atomically reserve a quota slot BEFORE calling the AI to prevent
    // concurrent requests from bypassing the free-tier limit (TOCTOU race).
    let newCount = 0;
    if (!isActive) {
      const { data: quotaResult, error: quotaError } = await supabaseAdmin.rpc(
        "increment_photo_usage_if_under_limit" as never,
        { user_uuid: userId, max_count: FREE_LIMIT } as never,
      );
      if (quotaError) {
        console.error("quota rpc failed", quotaError);
        throw new Error("Kunde inte kontrollera din användning. Försök igen.");
      }
      const row = Array.isArray(quotaResult) ? (quotaResult[0] as { allowed: boolean; new_count: number } | undefined) : undefined;
      if (!row?.allowed) {
        throw new Error("PAYWALL: Du har använt dina 5 gratis fotoanalyser. Uppgradera till Pro för 50 kr/mån.");
      }
      newCount = row.new_count;
    }

    const existing = data.existing ?? [];
    const systemPrompt = `Du är en expert på att inventera föremål i ett hem för försäkrings- och värderingssyfte. Analysera bilden och identifiera ägodelar som har ett ekonomiskt värde.

VIKTIGT — INKLUDERA ALDRIG följande (även om de syns tydligt i bilden):
- Kroppsdelar: fingrar, händer, armar, ben, fötter, ansikten, hår, hud
- Personer eller djur (människor, husdjur)
- Själva fotografen eller den som håller föremålet
- Skuggor, reflektioner, ljus, oskärpa
- Bakgrundsdetaljer som inte är ett konkret föremål (väggar, golv, tak — om de inte är en specifik möbel/inredning)
- Kläder eller smycken som personen i bilden bär just nu (om det inte är fokus i bilden)
- Smuts, damm, fläckar, repor
- Abstrakta saker (färger, mönster på en tapet, etc.)
- Mat- eller dryckesrester, sopor, skräp

INKLUDERA bara verkliga, konkreta ägodelar som har ett värde och som någon skulle vilja dokumentera för försäkring, värdering eller arvskifte.

KATEGORIER att välja mellan:
- "Grundinredning" — vanliga basmöbler och fasta hemdetaljer som de flesta hem har: stolar, bord, pallar, soffa, säng, mattor, gardiner, fönster, dörrar, takarmaturer, vägglampor, garderober, hyllor utan innehåll. Lägg ALLTID dessa här, även om det är flera (t.ex. "4 köksstolar").
- "Elektronik" — TV, datorer, telefoner, högtalare, hörlurar, sladdar, spelkonsoler m.m.
- "Kök" — köksredskap, porslin, glas, husgeråd, vitvaror som inte är inbyggda
- "Kläder & Skor"
- "Böcker & Media"
- "Dekoration & Konst" — tavlor, prydnadssaker, växter, ljusstakar
- "Verktyg & Hobby"
- "Leksaker & Spel"
- "Mat & Dryck"
- "Personliga ägodelar" — väskor, smycken, klockor
- "Övrigt" — bara om inget annat passar

För varje föremål: ge ett kort svenskt namn, kategori från listan ovan, och en kort beskrivning (märke, färg, material om synligt). Returnera ENDAST giltig JSON enligt schemat.

Föremål som redan har dokumenterats (lägg INTE till dessa igen om du ser samma sak): ${existing.join(", ") || "(inga ännu)"}`;

    const body = {
      model: "google/gemini-2.5-flash",
      messages: [
        { role: "system", content: systemPrompt },
        {
          role: "user",
          content: [
            { type: "text", text: "Identifiera alla nya föremål i bilden." },
            { type: "image_url", image_url: { url: data.imageBase64 } },
          ],
        },
      ],
      tools: [
        {
          type: "function",
          function: {
            name: "report_items",
            description: "Rapportera identifierade föremål",
            parameters: {
              type: "object",
              properties: {
                items: {
                  type: "array",
                  items: {
                    type: "object",
                    properties: {
                      name: { type: "string" },
                      category: { type: "string" },
                      description: { type: "string" },
                    },
                    required: ["name", "category"],
                  },
                },
              },
              required: ["items"],
            },
          },
        },
      ],
      tool_choice: { type: "function", function: { name: "report_items" } },
    };

    const res = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Lovable-API-Key": apiKey,
      },
      body: JSON.stringify(body),
    });

    if (!res.ok) {
      const txt = await res.text();
      console.error("AI gateway error (analyzeFrame)", res.status, txt);
      if (res.status === 429) throw new Error("För många förfrågningar, försök igen om en stund.");
      if (res.status === 402) throw new Error("AI-krediter slut. Lägg till krediter i arbetsytan.");
      throw new Error("Något gick fel med AI-anropet. Försök igen.");
    }

    const json = await res.json();

    const remaining = isActive ? null : Math.max(0, FREE_LIMIT - newCount);
    const toolCall = json?.choices?.[0]?.message?.tool_calls?.[0];
    if (!toolCall) return { items: [] as z.infer<typeof ItemSchema>[], remaining };

    try {
      const parsed = JSON.parse(toolCall.function.arguments);
      const items = z.array(ItemSchema).parse(parsed.items ?? []);
      return { items, remaining };
    } catch {
      return { items: [], remaining };
    }
  });

const DeepDiveSchema = z.object({
  name: z.string().min(1).max(200),
  description: z.string().max(500).optional().default(""),
  category: z.string().max(100).optional().default(""),
  imageBase64: z
    .string()
    .min(50)
    .max(MAX_IMAGE_BASE64, "Bilden är för stor. Försök igen med en mindre bild.")
    .refine((v) => v.startsWith("data:image/"), {
      message: "Endast base64 data-URL (data:image/…) accepteras",
    })
    .optional(),
  accessToken: z.string().min(1),
});

export const deepDiveItem = createServerFn({ method: "POST" })
  .inputValidator((d) => DeepDiveSchema.parse(d))
  .handler(async ({ data }) => {
    const apiKey = process.env.LOVABLE_API_KEY;
    if (!apiKey) throw new Error("LOVABLE_API_KEY saknas");

    const {
      data: { user },
      error: authError,
    } = await supabaseAdmin.auth.getUser(data.accessToken);

    if (authError || !user) {
      throw new Error("Din inloggning kunde inte verifieras. Logga in igen och försök på nytt.");
    }

    // Gate deep-dive behind active Pro subscription to prevent AI credit drain
    const { data: sub } = await supabaseAdmin
      .from("subscriptions")
      .select("status, current_period_end")
      .eq("user_id", user.id)
      .eq("environment", getServerPaddleEnvironment())
      .order("created_at", { ascending: false })
      .limit(1)
      .maybeSingle();

    const isActive = !!sub && (
      (["active", "trialing", "past_due"].includes(sub.status as string) &&
        (!sub.current_period_end || new Date(sub.current_period_end as string) > new Date())) ||
      (sub.status === "canceled" && sub.current_period_end && new Date(sub.current_period_end as string) > new Date())
    );

    if (!isActive) {
      throw new Error("PAYWALL: Djupdykning är en Pro-funktion. Uppgradera för 50 kr/mån.");
    }

    const systemPrompt = `Du är en expert produktidentifierare och värderare. Användaren har ett föremål som de vill veta mer om. Identifiera det så exakt som möjligt utifrån bilden och beskrivningen.

Svara på SVENSKA i markdown med följande sektioner:

## Vad är det troligen?
Beskriv föremålet så specifikt du kan: typ, troligt märke och modell, material, användningsområde. Var tydlig med osäkerhet ("troligen", "kan vara").

## Kännetecken
Punktlista med synliga detaljer som hjälper igenkänning (form, färg, logotyper, mönster, slitage).

## Uppskattat värde
Ungefärligt prisspann i SEK begagnat och nytt om relevant. Skriv "Svårt att uppskatta" om för osäkert.

## Sök vidare själv
Ge 3-5 konkreta sökfraser användaren kan klistra in på Google, Tradera, Blocket, Facebook Marketplace, Sellpy, Plick eller Garderoben.se för att hitta exakt matchning. Formattera som punktlista med fraserna i \`backticks\`. Nämn gärna vilken sajt som passar bäst för respektive sökfras.

Var ärlig om osäkerhet — gissa inte vilt. Om bilden är otydlig, säg det.`;

    const userContent: Array<Record<string, unknown>> = [
      {
        type: "text",
        text: `Föremål: ${data.name}\nKategori: ${data.category || "okänd"}\nNuvarande beskrivning: ${data.description || "(ingen)"}\n\nIdentifiera och djupdyk i vad detta är.`,
      },
    ];
    if (data.imageBase64) {
      userContent.push({ type: "image_url", image_url: { url: data.imageBase64 } });
    }

    const res = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Lovable-API-Key": apiKey,
      },
      body: JSON.stringify({
        model: "google/gemini-2.5-pro",
        messages: [
          { role: "system", content: systemPrompt },
          { role: "user", content: userContent },
        ],
      }),
    });

    if (!res.ok) {
      const txt = await res.text();
      console.error("AI gateway error (deepDiveItem)", res.status, txt);
      if (res.status === 429) throw new Error("För många förfrågningar, försök igen om en stund.");
      if (res.status === 402) throw new Error("AI-krediter slut. Lägg till krediter i arbetsytan.");
      throw new Error("Något gick fel med AI-anropet. Försök igen.");
    }

    const json = await res.json();
    const content: string = json?.choices?.[0]?.message?.content ?? "";
    return { content };
  });

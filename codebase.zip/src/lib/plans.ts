// Centralt ställe för plan-/pris-ID så de inte ligger spridda i UI:t.
export const PRO_MONTHLY_PRICE_ID = "prylkollen_pro_monthly";

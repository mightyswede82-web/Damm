import { useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Loader2, Sparkles, Check } from "lucide-react";
import { toast } from "sonner";
import { initializePaddle, getPaddlePriceId, getPaddleEnvironment } from "@/lib/paddle";
import { getCustomerPortalUrl } from "@/lib/payments.functions";
import { PRO_MONTHLY_PRICE_ID } from "@/lib/plans";



interface PaywallDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  userId: string;
  userEmail?: string;
  isSubscribed: boolean;
}

export function PaywallDialog({ open, onOpenChange, userId, userEmail, isSubscribed }: PaywallDialogProps) {
  const [loading, setLoading] = useState(false);
  const portalFn = useServerFn(getCustomerPortalUrl);

  const openCheckout = async () => {
    setLoading(true);
    try {
      await initializePaddle();
      const paddlePriceId = await getPaddlePriceId(PRO_MONTHLY_PRICE_ID);
      window.Paddle.Checkout.open({
        items: [{ priceId: paddlePriceId, quantity: 1 }],
        customer: userEmail ? { email: userEmail } : undefined,
        customData: { userId },
        settings: {
          displayMode: "overlay",
          successUrl: `${window.location.origin}/?checkout=success`,
          allowLogout: false,
          variant: "one-page",
        },
      });
      onOpenChange(false);
    } catch (e: any) {
      toast.error(e?.message || "Kunde inte öppna checkout");
    } finally {
      setLoading(false);
    }
  };

  const openPortal = async () => {
    setLoading(true);
    try {
      const { url } = await portalFn();
      window.open(url, "_blank");
    } catch (e: any) {
      toast.error(e?.message || "Kunde inte öppna kundportalen");
    } finally {
      setLoading(false);
    }
  };

  if (isSubscribed) {
    return (
      <Dialog open={open} onOpenChange={onOpenChange}>
        <DialogContent className="max-w-md rounded-3xl">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Sparkles className="h-5 w-5 text-primary" /> Du är PrylKollen Pro
            </DialogTitle>
            <DialogDescription>Obegränsade fotoanalyser ingår i din prenumeration.</DialogDescription>
          </DialogHeader>
          <Button onClick={openPortal} disabled={loading} variant="outline" className="w-full rounded-2xl">
            {loading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
            Hantera prenumeration
          </Button>
        </DialogContent>
      </Dialog>
    );
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md rounded-3xl">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-2xl">
            <Sparkles className="h-6 w-6 text-primary" /> Uppgradera till Pro
          </DialogTitle>
          <DialogDescription>Få obegränsade fotoanalyser för 50 kr/mån.</DialogDescription>
        </DialogHeader>

        <div className="rounded-2xl border bg-muted/30 p-5">
          <div className="flex items-baseline gap-1">
            <span className="text-4xl font-bold">50 kr</span>
            <span className="text-sm text-muted-foreground">/mån</span>
          </div>
          <ul className="mt-4 space-y-2 text-sm">
            <li className="flex items-center gap-2">
              <Check className="h-4 w-4 text-primary" /> Obegränsade fotoanalyser
            </li>
            <li className="flex items-center gap-2">
              <Check className="h-4 w-4 text-primary" /> Djupdyk i varje föremål
            </li>
            <li className="flex items-center gap-2">
              <Check className="h-4 w-4 text-primary" /> Avsluta när du vill
            </li>
          </ul>
        </div>

        <Button onClick={openCheckout} disabled={loading} size="lg" className="w-full rounded-2xl">
          {loading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
          Uppgradera nu
        </Button>
        {getPaddleEnvironment() === "sandbox" && (
          <p className="text-center text-xs text-muted-foreground">
            Testläge — använd kort 4242 4242 4242 4242
          </p>
        )}
      </DialogContent>
    </Dialog>
  );
}

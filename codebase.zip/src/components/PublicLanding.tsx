import { Link } from "@tanstack/react-router";
import { Button } from "@/components/ui/button";
import { SiteFooter } from "@/components/SiteFooter";
import { Camera, Check, Sparkles, Package } from "lucide-react";

export function PublicLanding() {
  return (
    <div className="min-h-screen bg-background flex flex-col">
      <header className="border-b">
        <div className="mx-auto flex max-w-6xl items-center justify-between px-4 py-4">
          <Link to="/" className="text-sm font-semibold tracking-tight">PrylKollen</Link>
          <div className="flex items-center gap-2">
            <Link to="/pricing" className="hidden sm:inline-block text-sm text-muted-foreground hover:text-foreground px-3 py-1.5">
              Pris
            </Link>
            <Button asChild size="sm" variant="ghost"><Link to="/login">Logga in</Link></Button>
            <Button asChild size="sm" className="rounded-full"><Link to="/login">Kom igång</Link></Button>
          </div>
        </div>
      </header>

      <main className="flex-1">
        {/* Hero */}
        <section className="mx-auto max-w-5xl px-4 py-16 text-center sm:py-24">
          <div className="mb-4 inline-flex items-center gap-1.5 rounded-full border bg-card px-3 py-1 text-[11px] font-semibold uppercase tracking-widest text-muted-foreground">
            <span className="h-1.5 w-1.5 rounded-full bg-primary" /> AI-driven inventering
          </div>
          <h1 className="text-4xl font-bold tracking-tight sm:text-6xl">
            Katalogisera hela hemmet — <span className="text-primary">på en kvart</span>
          </h1>
          <p className="mx-auto mt-5 max-w-xl text-base text-muted-foreground sm:text-lg">
            Filma långsamt runt i rummet. PrylKollen identifierar dina prylar, sorterar dem i kategorier och uppskattar
            värdet — perfekt inför försäkring, flytt eller bara för koll.
          </p>
          <div className="mt-8 flex flex-col items-center justify-center gap-3 sm:flex-row">
            <Button asChild size="lg" className="rounded-2xl"><Link to="/login"><Camera className="mr-2 h-4 w-4" /> Börja gratis</Link></Button>
            <Button asChild size="lg" variant="ghost" className="rounded-2xl"><Link to="/pricing">Se pris</Link></Button>
          </div>
          <p className="mt-3 text-xs text-muted-foreground">5 fotoanalyser gratis — inget kort krävs.</p>
        </section>

        {/* Features */}
        <section className="border-t bg-muted/30">
          <div className="mx-auto grid max-w-5xl gap-6 px-4 py-12 sm:grid-cols-3 sm:py-16">
            <Feature icon={<Camera className="h-5 w-5" />} title="Filma eller fota">
              Använd kameran live eller ladda upp bilder. AI:n hittar föremålen automatiskt.
            </Feature>
            <Feature icon={<Package className="h-5 w-5" />} title="Sorteras i kategorier">
              Möbler, elektronik, kläder — allt hamnar prydligt grupperat med beskrivningar.
            </Feature>
            <Feature icon={<Sparkles className="h-5 w-5" />} title="Djupdyk i varje pryl">
              Få mer information, värdeuppskattning och köpråd direkt i appen.
            </Feature>
          </div>
        </section>

        {/* Pricing preview */}
        <section className="mx-auto max-w-4xl px-4 py-16 sm:py-20">
          <div className="text-center">
            <h2 className="text-3xl font-bold tracking-tight sm:text-4xl">Enkel prissättning</h2>
            <p className="mt-2 text-sm text-muted-foreground">Börja gratis. Uppgradera när du vill ha mer.</p>
          </div>

          <div className="mt-10 grid gap-5 sm:grid-cols-2">
            <div className="rounded-3xl border bg-card p-6">
              <h3 className="text-lg font-semibold">Gratis</h3>
              <div className="mt-2 flex items-baseline gap-1">
                <span className="text-4xl font-bold">0 kr</span>
                <span className="text-sm text-muted-foreground">/mån</span>
              </div>
              <ul className="mt-5 space-y-2 text-sm">
                <li className="flex items-center gap-2"><Check className="h-4 w-4 text-primary" /> 5 fotoanalyser</li>
                <li className="flex items-center gap-2"><Check className="h-4 w-4 text-primary" /> AI-identifiering</li>
                <li className="flex items-center gap-2"><Check className="h-4 w-4 text-primary" /> Sparas på din enhet</li>
              </ul>
            </div>
            <div className="rounded-3xl border-2 border-primary bg-card p-6">
              <h3 className="flex items-center gap-1.5 text-lg font-semibold"><Sparkles className="h-4 w-4 text-primary" /> Pro</h3>
              <div className="mt-2 flex items-baseline gap-1">
                <span className="text-4xl font-bold">50 kr</span>
                <span className="text-sm text-muted-foreground">/mån</span>
              </div>
              <ul className="mt-5 space-y-2 text-sm">
                <li className="flex items-center gap-2"><Check className="h-4 w-4 text-primary" /> Obegränsade fotoanalyser</li>
                <li className="flex items-center gap-2"><Check className="h-4 w-4 text-primary" /> Djupdyk i varje föremål</li>
                <li className="flex items-center gap-2"><Check className="h-4 w-4 text-primary" /> 30 dagars öppet köp</li>
              </ul>
            </div>
          </div>
          <div className="mt-8 text-center">
            <Button asChild size="lg" className="rounded-2xl"><Link to="/login">Skapa gratis konto</Link></Button>
          </div>
        </section>
      </main>

      <SiteFooter />
    </div>
  );
}

function Feature({ icon, title, children }: { icon: React.ReactNode; title: string; children: React.ReactNode }) {
  return (
    <div>
      <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-primary text-primary-foreground">{icon}</div>
      <h3 className="mt-3 text-base font-semibold">{title}</h3>
      <p className="mt-1 text-sm text-muted-foreground leading-relaxed">{children}</p>
    </div>
  );
}

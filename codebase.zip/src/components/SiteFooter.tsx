import { Link } from "@tanstack/react-router";

export function SiteFooter() {
  return (
    <footer className="border-t bg-muted/30">
      <div className="mx-auto max-w-6xl px-4 py-8 text-sm text-muted-foreground">
        <div className="flex flex-col items-center gap-3 sm:flex-row sm:justify-between">
          <p>© {new Date().getFullYear()} Lindgren — PrylKollen</p>
          <nav className="flex flex-wrap items-center justify-center gap-x-5 gap-y-2">
            <Link to="/pricing" className="hover:text-foreground">Pris</Link>
            <Link to="/terms" className="hover:text-foreground">Villkor</Link>
            <Link to="/privacy" className="hover:text-foreground">Integritetspolicy</Link>
            <Link to="/refund-policy" className="hover:text-foreground">Återbetalning</Link>
          </nav>
        </div>
      </div>
    </footer>
  );
}

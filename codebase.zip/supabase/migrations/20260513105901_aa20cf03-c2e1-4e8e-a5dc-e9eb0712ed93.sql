
revoke execute on function public.has_active_subscription(uuid, text) from public, anon, authenticated;

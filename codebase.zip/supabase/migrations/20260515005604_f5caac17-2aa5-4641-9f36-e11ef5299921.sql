
CREATE OR REPLACE FUNCTION public.increment_photo_usage_if_under_limit(
  user_uuid uuid,
  max_count integer
)
RETURNS TABLE(allowed boolean, new_count integer)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  updated_count integer;
BEGIN
  INSERT INTO public.photo_usage (user_id, count, updated_at)
  VALUES (user_uuid, 1, now())
  ON CONFLICT (user_id) DO UPDATE
    SET count = public.photo_usage.count + 1,
        updated_at = now()
    WHERE public.photo_usage.count < max_count
  RETURNING public.photo_usage.count INTO updated_count;

  IF updated_count IS NULL THEN
    SELECT pu.count INTO updated_count
    FROM public.photo_usage pu
    WHERE pu.user_id = user_uuid;
    RETURN QUERY SELECT false, COALESCE(updated_count, 0);
  ELSE
    RETURN QUERY SELECT true, updated_count;
  END IF;
END;
$$;

-- Ensure photo_usage.user_id has a primary key/unique constraint for ON CONFLICT
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint
    WHERE conrelid = 'public.photo_usage'::regclass
    AND contype IN ('p','u')
  ) THEN
    ALTER TABLE public.photo_usage ADD PRIMARY KEY (user_id);
  END IF;
END$$;


REVOKE EXECUTE ON FUNCTION public.increment_photo_usage_if_under_limit(uuid, integer) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.increment_photo_usage_if_under_limit(uuid, integer) TO service_role;
